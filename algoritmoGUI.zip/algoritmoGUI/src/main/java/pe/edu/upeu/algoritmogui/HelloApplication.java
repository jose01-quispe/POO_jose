package pe.edu.upeu.algoritmogui;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        Label mensaje = new Label("Bienvenido a JavaFX");
        TextField txtnombre=new TextField();

        mensaje.setStyle("-fx-font-size: 18px;");

        Button boton = new Button("Saludar");
        //deducir igv
        Label smgmonto=new Label("monto:");
        TextField txtmonto=new TextField();
        Button bncalcular=new Button("Deducir igv");
        Label resultado=new Label();
        HBox hb=new HBox(10,smgmonto,txtmonto,bncalcular,resultado);
        //accion
        bncalcular.setOnAction(event -> {
            double resul=Double.parseDouble(txtmonto.getText()) - Double.parseDouble(txtmonto.getText())/1.18;
            resultado.setText("PV:" +(Double.parseDouble(txtmonto.getText())/1.18)+"ibv:"+String.valueOf(resul));
        });


        boton.setOnAction(evento ->
                mensaje.setText("¡Hola! "+txtnombre.getText()));

        VBox raiz = new VBox(15, mensaje,txtnombre, boton, hb);
        raiz.setAlignment(Pos.CENTER);
        raiz.setStyle("-fx-padding: 30;");

        Scene escena = new Scene(raiz, 400, 250);

        stage.setTitle("Hola JavaFX");
        stage.setScene(escena);
        stage.show();
    }
}
